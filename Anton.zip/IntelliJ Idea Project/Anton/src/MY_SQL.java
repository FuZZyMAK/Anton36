import java.sql.*;

public class MY_SQL {
    private String url = "jdbc:mysql://localhost:3306/design_studio?useSSL=false&serverTimezone=Europe/Moscow";
    private String user = "root";
    private String pass = "eather1192@How91";
    private Connection connection = null;

    public boolean openConnection() {
        try {
            this.connection = DriverManager.getConnection(url, user, pass);
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public void closeConnection() {
        try {
            this.connection.close();
        }catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean getAllDesigners() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `designers`");
            String result = "";
            int count = 1;
            while (rs.next()) {
                String designer_surname = rs.getString("designer_surname");
                String designer_name = rs.getString("designer_name");
                String designer_lastname = rs.getString("designer_lastname");
                int designer_cost = rs.getInt("cost");
                result += count + ". " + designer_surname + " " + designer_name + " " + designer_lastname + ", мин.цена на услуги: " + designer_cost + "\n";
                count++;
            }

            if (!result.isEmpty()) {
                System.out.println("Список дизайнеров нашей студии:\n" + result);
            }else{
                System.out.println("В нашей студии пока нет дизайнеров...\n");
            }
            return true;
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }
    public boolean getAllClients() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `clients`");
            String result = "";
            int count = 1;
            while (rs.next()) {
                String client_surname = rs.getString("client_surname");
                String client_name = rs.getString("client_name");
                String client_lastname = rs.getString("client_lastname");
                result += count + ". " + client_surname + " " + client_name + " " + client_lastname + "\n";
                count++;
            }
            if (!result.isEmpty()) {
                System.out.println("Список клиентов нашей студии:\n" + result);
            }else{
                System.out.println("В нашей студии пока нет клиентов...\n");
            }
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getMostPopularDesigners() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `designers` ORDER BY `designer_demand` DESC LIMIT 3;");
            String result = "";
            int count = 1;
            while (rs.next()) {
                String designer_surname = rs.getString("designer_surname");
                String designer_name = rs.getString("designer_name");
                String designer_lastname = rs.getString("designer_lastname");
                int designer_demand = rs.getInt("designer_demand");

                result += count + ". " + designer_surname + " " + designer_name + " " + designer_lastname + ", кол-во выполненных заказов: " + designer_demand + "\n";
                count++;
            }

            if (!result.isEmpty()) {
                System.out.println("Список трёх самых популярных дизайнеров нашей студии:\n" + result);
            }else{
                System.out.println("В нашей студии пока нет дизайнеров...\n");
            }
            return true;
        }catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getMostPopularClients() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `clients` ORDER BY `client_demand` DESC LIMIT 3;");
            String result = "";
            int count = 1;
            while (rs.next()) {
                String client_surname = rs.getString("client_surname");
                String client_name = rs.getString("client_name");
                String client_lastname = rs.getString("client_lastname");
                int client_demand = rs.getInt("client_demand");

                result += count + ". " + client_surname + " " + client_name + " " + client_lastname + ", кол-во заказов: " + client_demand + "\n";
                count++;
            }

            if (!result.isEmpty()) {
                System.out.println("Список трёх самых популярных клиентов нашей студии:\n" + result);
            }else{
                System.out.println("В нашей студии пока нет клиентов...\n");
            }
            return false;
        }catch (SQLException e) {
            e.printStackTrace();
            return true;
        }
    }
    public boolean getOrdersByClientSurname(String surname) {
        try {
            int id = this.getClientIdBySurname(surname);
            if (id == -1) {
                System.out.println("Не удалось найти клиента с такой фамилией!");
                return true;
            }
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `works` WHERE `id_client` = ?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            String result = "";
            while (resultSet.next()) {
                int paid = resultSet.getInt("paid");
                String service = resultSet.getString("service");
                int id_designer = resultSet.getInt("id_designer");
                int id_work = resultSet.getInt("id_work");
                String designer_fullname = this.getDesignerFullNameById(id_designer);
                if (designer_fullname.isEmpty()) {
                    designer_fullname = "Неизвестно";
                }

                result += "Заказ №" + id_work + ". Оплачено: " + paid + " руб. Название работы: " + service + ". Дизайнер: " + designer_fullname + "\n";
            }
            if (!result.isEmpty()) {
                System.out.println("Список заказов клиента:\n" + result);
            }else{
                System.out.println("Данный клиент ещё ничего не заказывал...\n");
            }
            return true;
        }catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getWorksByDesignerSurname(String surname) {
        try {
            int id = this.getDesignerIdBySurname(surname);
            if (id == -1) {
                System.out.println("Не удалось найти дизайнера с такой фамилией!");
                return true;
            }
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `works` WHERE `id_designer` = ?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            String result = "";
            while (resultSet.next()) {
                int paid = resultSet.getInt("paid");
                String service = resultSet.getString("service");
                int id_client = resultSet.getInt("id_client");
                int id_work = resultSet.getInt("id_work");
                String client_fullname = this.getClientFullNameById(id_client);
                if (client_fullname.isEmpty()) {
                    client_fullname = "Неизвестно";
                }

                result += "Заказ №" + id_work + ". Получено: " + paid + " руб. Название работы: " + service + ". Клиент: " + client_fullname + "\n";
            }
            if (!result.isEmpty()) {
                System.out.println("Список работ дизайнера:\n" + result);
            }else{
                System.out.println("Данный дизайнер ещё не работал...\n");
            }
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getCostlyWorks() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `works` ORDER BY `paid` DESC LIMIT 3;");
            String result = "";
            while (rs.next()) {
                int paid = rs.getInt("paid");
                String service = rs.getString("service");
                int id_designer = rs.getInt("id_designer");
                int id_client = rs.getInt("id_client");
                int id_work = rs.getInt("id_work");
                String client_fullname = this.getClientFullNameById(id_client);
                String designer_fullname = this.getDesignerFullNameById(id_designer);
                if (client_fullname.isEmpty()) {
                    client_fullname = "Неизвестно";
                }
                if (designer_fullname.isEmpty()) {
                    designer_fullname = "Неизвестно";
                }

                result += "Заказ №" + id_work + ". Цена: " + paid + " руб. Дизайнер: " + designer_fullname + ". Клиент: " + client_fullname + ". Название работы: " +service + "\n";
            }

            if (!result.isEmpty()) {
                System.out.println("ТОП-3 самых дорогих работ:\n" + result);
            }else{
                System.out.println("В нашей студии ещё не было заказов...\n");
            }
            return true;
        }catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getStudioRevenue() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT `paid` FROM `works`;");
            int revenue = 0;
            while (rs.next()) {
                revenue += rs.getInt("paid");
            }

            System.out.println("Общая выручка студии: " + revenue + " руб.");
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getAllWorks() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `works`;");
            String result = "";
            while (rs.next()) {
                int paid = rs.getInt("paid");
                String service = rs.getString("service");
                int id_designer = rs.getInt("id_designer");
                int id_client = rs.getInt("id_client");
                int id_work = rs.getInt("id_work");
                String client_fullname = this.getClientFullNameById(id_client);
                String designer_fullname = this.getDesignerFullNameById(id_designer);
                if (client_fullname.isEmpty()) {
                    client_fullname = "Неизвестно";
                }
                if (designer_fullname.isEmpty()) {
                    designer_fullname = "Неизвестно";
                }

                result += "Заказ №" + id_work + ". Цена: " + paid + " руб. Дизайнер: " + designer_fullname + ". Клиент: " + client_fullname + ". Название работы: " +service + "\n";
            }

            if (!result.isEmpty()) {
                System.out.println("Список всех работ студии: " + result + " руб.");
            }else{
                System.out.println("В нашей студии ещё не было заказов...\n");
            }
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean getDesignersPayDay() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `designers`;");
            String result = "";
            while (rs.next()) {
                int id_designer = rs.getInt("id_designer");
                String designer_surname = rs.getString("designer_surname");
                String designer_name = rs.getString("designer_name");
                String designer_lastname = rs.getString("designer_lastname");
                int payday = 0;

                PreparedStatement preparedStatement = connection.prepareStatement("SELECT `paid` FROM `works` WHERE `id_designer` = ?");
                preparedStatement.setInt(1, id_designer);
                ResultSet rs2 = preparedStatement.executeQuery();
                while (rs2.next()) {
                    payday += rs2.getInt("paid");
                }

                result += "Дизайнер №"+id_designer+" - " + designer_surname + " " + designer_name + " " + designer_lastname + ". Заработал за период: " + payday + " руб.";
            }

            if (!result.isEmpty()) {
                System.out.println("Зарплаты дизайнеров нашей студии:\n" + result);
            }else{
                System.out.println("Зарплаты дизайнеров ещё не сформированы!");
            }
            return true;
        }catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private int getClientIdBySurname(String surname) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `clients` WHERE `client_surname` = ?");
            preparedStatement.setString(1, surname);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("id_client");
            }else return -1;
        }catch(SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    private String getClientFullNameById(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `clients` WHERE `id_client` = ?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("client_surname") + " " + resultSet.getString("client_name") + " " + resultSet.getString("client_lastname");
            }else return "";
        }catch(SQLException e) {
            e.printStackTrace();
            return "";
        }
    }
    private String getDesignerFullNameById(int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `designers` WHERE `id_designer` = ?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("designer_surname") + " " + resultSet.getString("designer_name") + " " + resultSet.getString("designer_lastname");
            }else return "";
        }catch(SQLException e) {
            e.printStackTrace();
            return "";
        }
    }
    private int getDesignerIdBySurname(String surname) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM `designers` WHERE `designer_surname` = ?");
            preparedStatement.setString(1, surname);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("id_designer");
            }else return -1;
        }catch(SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

}