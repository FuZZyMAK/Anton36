import java.util.Scanner;

public class Main {
    private static final MY_SQL mysql = new MY_SQL();
    private static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        if (mysql.openConnection()) {
            while (true) {
                System.out.println(getMenuText());
                int choice = scanner.nextInt();
                menuSwitcher(choice);
            }
        }
    }

    private static String getMenuText() {
        return """
                Выберите действие:
                1. Список всех дизайнеров
                2. Список всех клиентов
                3. Три самых популярных дизайнеров
                4. Три самых частых клиентов
                5. Список заказов по фамилии клиента
                6. Все работы дизайнера по его фамилии
                7. ТОП-3 самые дорогие работы
                8. Общую выручку студии
                9. Список всех работ
                10. Показать запралыт дизайнеров за текущий период
                """;
    }

    private static void menuSwitcher(int choice) {
        switch (choice) {
            case 1:
                if (!mysql.getAllDesigners()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 2:
                if (!mysql.getAllClients()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 3:
                if (!mysql.getMostPopularDesigners()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 4:
                if (!mysql.getMostPopularClients()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 5:
                System.out.println("Введите фамилию клиента:");
                String c_surname = (new Scanner(System.in)).nextLine();
                if (!mysql.getOrdersByClientSurname(c_surname)) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 6:
                System.out.println("Введите фамилию дизайнера:");
                String d_surname = (new Scanner(System.in)).nextLine();
                if (!mysql.getWorksByDesignerSurname(d_surname)) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 7:
                if (!mysql.getCostlyWorks()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 8:
                if (!mysql.getStudioRevenue()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 9:
                if (!mysql.getAllWorks()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            case 10:
                if (!mysql.getDesignersPayDay()) {
                    System.out.println("Не удалось выполнить запрос!");
                }
                break;
            default:
                System.out.println("Я не знаю такого пункта, попробуйте ещё раз.");
                break;
        }
    }
}